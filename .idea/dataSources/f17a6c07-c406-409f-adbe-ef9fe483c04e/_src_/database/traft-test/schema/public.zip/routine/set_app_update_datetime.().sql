CREATE FUNCTION set_app_update_datetime () RETURNS trigger
	LANGUAGE plpgsql
AS $$

BEGIN

  IF TG_OP = 'INSERT' AND COALESCE(NEW.current_app_version, '') <> '' THEN
    NEW.current_app_version_update := ('now'::text)::timestamp(0) without time zone;
  END IF;

  IF TG_OP = 'UPDATE' AND COALESCE(NEW.current_app_version, '') <> COALESCE(OLD.current_app_version, '') THEN
    NEW.current_app_version_update := ('now'::text)::timestamp(0) without time zone;
  END IF;

  RETURN NEW;

END;
$$
