CREATE TRIGGER set_app_update_datetime
BEFORE INSERT OR UPDATE ON vehicles
FOR EACH ROW EXECUTE PROCEDURE set_app_update_datetime()