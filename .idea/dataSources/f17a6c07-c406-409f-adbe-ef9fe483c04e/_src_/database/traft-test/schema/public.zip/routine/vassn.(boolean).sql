CREATE FUNCTION vassn (boolean) RETURNS integer
	LANGUAGE plpgsql
AS $$
DECLARE bexpr alias for $1;
BEGIN
if bexpr
then return 0;
else return 2000000000;
end if;
END
$$
