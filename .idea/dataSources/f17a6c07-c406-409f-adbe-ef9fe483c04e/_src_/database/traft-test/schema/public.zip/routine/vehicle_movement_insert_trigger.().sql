CREATE FUNCTION vehicle_movement_insert_trigger () RETURNS trigger
	LANGUAGE plpgsql
AS $$

DECLARE
  table_master    varchar(255)        := 'vehicle_movement';
  table_part      varchar(255)        := '';
BEGIN
  -- Даём имя партиции --------------------------------------------------
  table_part := table_master
                || '_y' || date_part( 'year', NEW.created_at )::text
                || '_m' || date_part( 'month', NEW.created_at )::text;
  
  -- Проверяем партицию на существование --------------------------------
  PERFORM
    1
  FROM
    pg_class
  WHERE
    relname = table_part
  LIMIT
    1;
  
  -- Если её ещё нет, то создаём --------------------------------------------
  IF NOT FOUND
  THEN
    -- Cоздаём партицию, наследуя мастер-таблицу --------------------------
    EXECUTE '
            CREATE TABLE ' || table_part || ' (
            id BIGINT DEFAULT nextval(''' || table_master || '_id_seq''::regclass)
            )
            INHERITS ( ' || table_master || ' )
            WITH ( OIDS=FALSE )';
    
    -- Создаём индексы для текущей партиции -------------------------------
    EXECUTE '
            CREATE INDEX ' || table_part || '__created_at__index
            ON ' || table_part || '
            USING btree
            (created_at)';
    EXECUTE '
            CREATE INDEX ' || table_part || '__id__index
            ON ' || table_part || '
            USING btree
            (id)';
    EXECUTE '
            CREATE INDEX ' || table_part || '__time_mark__index
            ON ' || table_part || '
            USING btree
            (time_mark)';
  END IF;
  
  -- Вставляем данные в партицию --------------------------------------------
  EXECUTE '
        INSERT INTO ' || table_part || '
        SELECT ( (' || quote_literal(NEW) || ')::' || TG_RELNAME || ' ).*';
  
  RETURN NULL;
END;
$$
