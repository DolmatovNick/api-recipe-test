CREATE FUNCTION set_order_archive () RETURNS trigger
	LANGUAGE plpgsql
AS $$

BEGIN
  IF NEW.is_archive = true THEN
    RETURN NEW;
  END IF;

  IF NEW.canc = true OR NEW.is_checked1c = true OR NEW.status >= 6 THEN
    NEW.is_archive := true;
  END IF;

  if NEW.canc = false AND NEW.is_checked1c = false AND NEW.status < 6 THEN
    NEW.is_archive := false;
  END IF;

  RETURN NEW;

END;
$$
